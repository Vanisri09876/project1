/* eslint-disable react/no-unknown-property */


function CompanyCarousel() {
  return (
<div className="mt-4 mb-4">
<marquee behavior="scroll" scrolldelay="0" direction="left">
<img className="inline" src="https://www.paperplanetech.co/static/media/client8.fdaee9618e9dcc976fea.png" width="180" height="180" alt="Flying Bat" />
<img className="inline" src="https://www.paperplanetech.co/static/media/client5.98017aa34e119c58e644.png" width="180" height="180" alt="Flying Bat" />
<img className="inline" src="https://www.paperplanetech.co/static/media/client2.5604d158cce6000f455e.png" width="180" height="180" alt="Flying Bat" />
<img className="inline" src="https://www.paperplanetech.co/static/media/client8.fdaee9618e9dcc976fea.png" width="180" height="180" alt="Flying Bat" />
<img className="inline" src="https://www.paperplanetech.co/static/media/client5.98017aa34e119c58e644.png" width="180" height="180" alt="Flying Bat" />
<img className="inline" src="https://www.paperplanetech.co/static/media/client2.5604d158cce6000f455e.png" width="180" height="180" alt="Flying Bat" />
</marquee>
</div>
  )
}

export default CompanyCarousel